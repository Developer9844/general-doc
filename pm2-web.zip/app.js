const express = require('express');
const { exec } = require('child_process');
const util = require('util');
const cors = require('cors');
const path = require('path');
const execPromise = util.promisify(exec);

const app = express();
app.use(cors());
app.use(express.json());

// Serve static files from public directory
app.use(express.static('public'));

// ====== CONFIGURATION ======
const USERS = ['ankushk'];
const NODE_PATH = '/usr/local/nvm/versions/node/v18.20.8/bin';
const PM2_PATH = `${NODE_PATH}/pm2`;

// ====== HELPER FUNCTION ======
async function runPM2Command(user, cmd) {
  const pm2Home = `/home/${user}/.pm2`;
  const fullCmd = `sudo -u ${user} PM2_HOME=${pm2Home} PATH=${NODE_PATH}:$PATH ${PM2_PATH} ${cmd}`;
  return execPromise(fullCmd);
}

// ====== GET ALL PM2 PROCESSES ======
async function getAllPM2Processes() {
  try {
    const allProcesses = [];

    for (const user of USERS) {
      try {
        const { stdout } = await runPM2Command(user, 'jlist');
        const processes = JSON.parse(stdout);

        processes.forEach(proc => {
          allProcesses.push({ ...proc, user });
        });
      } catch (err) {
        console.log(`No PM2 for user ${user}: ${err.message}`);
      }
    }

    return allProcesses;
  } catch (error) {
    throw error;
  }
}

// ====== ROUTES ======

// Get all processes
app.get('/api/processes', async (req, res) => {
  try {
    const processes = await getAllPM2Processes();
    res.json(processes);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Execute PM2 actions
app.post('/api/action', async (req, res) => {
  const { user, pmId, action } = req.body;
  
  const validActions = ['start', 'stop', 'restart', 'delete', 'reload'];
  if (!validActions.includes(action)) {
    return res.status(400).json({ error: 'Invalid action' });
  }
  
  try {
    const { stdout, stderr } = await runPM2Command(user, `${action} ${pmId}`);
    res.json({ success: true, output: stdout || stderr });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get logs for a process
app.get('/api/logs', async (req, res) => {
  const { user, pmId } = req.query;
  
  try {
    const { stdout } = await runPM2Command(user, `logs ${pmId} --lines 100 --nostream`);
    res.json({ logs: stdout });
  } catch (error) {
    res.status(500).json({ error: error.message, logs: '' });
  }
});

// ====== START SERVER ======
app.listen(3003, () => {
  console.log('✅ PM2 Admin Panel running on http://localhost:3003');
});
 
