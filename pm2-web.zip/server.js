const express = require('express');
const { exec } = require('child_process');
const util = require('util');
const cors = require('cors');
const path = require('path');
const execPromise = util.promisify(exec);

const app = express();
app.use(cors());
app.use(express.json());

// Serve static files from public directory
app.use(express.static('public'));

// ====== CONFIGURATION ======
const USERS = ['gitlab-runner', 'root', 'moontech12'];
const PM2_PATH = '/usr/bin/pm2';

// ====== HELPER FUNCTION ======
async function runPM2Command(user, cmd) {
  let fullCmd;
  
  if (user === 'root') {
    fullCmd = `${PM2_PATH} ${cmd}`;
  } else {
    const homePath = `/home/${user}`;
    const pm2Home = `${homePath}/.pm2`;
    fullCmd = `sudo -u ${user} -H bash -c "export PM2_HOME=${pm2Home} && ${PM2_PATH} ${cmd}"`;
  }
  
  return execPromise(fullCmd);
}

// ====== EXTRACT JSON FROM PM2 OUTPUT ======
function extractJSON(output) {
  // Remove ANSI color codes
  const cleanOutput = output.replace(/\x1B\[[0-9;]*[a-zA-Z]/g, '');
  
  // Find the first '[' or '{' character and parse from there
  const jsonStart = cleanOutput.search(/[\[\{]/);
  
  if (jsonStart === -1) {
    throw new Error('No JSON found in output');
  }
  
  const jsonString = cleanOutput.substring(jsonStart).trim();
  return JSON.parse(jsonString);
}

// ====== GET ALL PM2 PROCESSES ======
async function getAllPM2Processes() {
  try {
    const allProcesses = [];

    for (const user of USERS) {
      try {
        const { stdout } = await runPM2Command(user, 'jlist');
        const processes = extractJSON(stdout);
        
        processes.forEach(proc => {
          allProcesses.push({ ...proc, user });
        });
      } catch (err) {
        console.log(`No PM2 processes for user ${user}: ${err.message}`);
      }
    }

    return allProcesses;
  } catch (error) {
    throw error;
  }
}

// ====== ROUTES ======

// Get all processes
app.get('/api/processes', async (req, res) => {
  try {
    const processes = await getAllPM2Processes();
    res.json(processes);
  } catch (error) {
    console.error('Error fetching processes:', error);
    res.status(500).json({ error: error.message });
  }
});

// Execute PM2 actions
app.post('/api/action', async (req, res) => {
  const { user, pmId, action } = req.body;
  
  const validActions = ['start', 'stop', 'restart', 'delete', 'reload'];
  if (!validActions.includes(action)) {
    return res.status(400).json({ error: 'Invalid action' });
  }
  
  try {
    const { stdout, stderr } = await runPM2Command(user, `${action} ${pmId}`);
    res.json({ success: true, output: stdout || stderr });
  } catch (error) {
    console.error('Error executing action:', error);
    res.status(500).json({ error: error.message });
  }
});

// Get logs for a process
app.get('/api/logs', async (req, res) => {
  const { user, pmId } = req.query;
  
  try {
    const { stdout } = await runPM2Command(user, `logs ${pmId} --lines 1000 --nostream`);
    res.json({ logs: stdout });
  } catch (error) {
    console.error('Error fetching logs:', error);
    res.status(500).json({ error: error.message, logs: '' });
  }
});

// Update PM2 for a specific user (removes out-of-date warnings)
app.post('/api/update-pm2', async (req, res) => {
  const { user } = req.body;
  
  if (!USERS.includes(user)) {
    return res.status(400).json({ error: 'Invalid user' });
  }
  
  try {
    const { stdout } = await runPM2Command(user, 'update');
    res.json({ success: true, output: stdout });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get system info
app.get('/api/system', async (req, res) => {
  try {
    const { stdout: memInfo } = await execPromise('free -m');
    const { stdout: cpuInfo } = await execPromise('cat /proc/cpuinfo | grep "model name" | head -1');
    const { stdout: uptime } = await execPromise('uptime -p');
    
    res.json({
      memory: memInfo,
      cpu: cpuInfo.trim(),
      uptime: uptime.trim()
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ====== START SERVER ======
const PORT = process.env.PORT || 3002;
app.listen(PORT, () => {
  console.log('✅ PM2 Multi-User Admin Panel');
  console.log(`📊 Dashboard: http://localhost:${PORT}`);
  console.log(`👥 Monitoring users: ${USERS.join(', ')}`);
  console.log('');
  console.log('💡 To remove "out-of-date" warnings, run:');
  USERS.forEach(user => {
    const cmd = user === 'root' ? 'pm2 update' : `sudo -u ${user} pm2 update`;
    console.log(`   ${cmd}`);
  });
}); 
